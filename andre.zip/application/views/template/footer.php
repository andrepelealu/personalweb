

    <footer class="footer-area footer--light">

      <div class="mini-footer">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="copyright-text">
                <p>© 2018
                  <a href="#">:)</a>. All rights reserved. Created by
                  <a href="#">AndrePelealu &copy</a>
                </p>

              </div>


            </div>
          </div>
        </div>
      </div>
    </footer>


	</body>
</html>
