
<body>
  <div class="container-fluid bg">

    <a href="<?php echo base_url()?>" class="logo">AndrePelealu</a> <!-- site name -->
    <div class="container">
      <div class="row">
        <div class="col-md-6 ">
          <p>foto</p>
        </div>
        <div class="col-md-6">
          <p>kanan</p>
        </div>
      </div>
    </div>

  </div>
</body>
