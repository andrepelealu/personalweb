
<body>
  <div class="container-fluid bg">
  <div class="container">
  		<a href="<?php echo base_url('')?>" class="logo">AndrePelealu</a>
  	<div class="row">
  		<div class="col-md-12 col-xs-12">
  			<center>
          <div class="container">
  <div class="jumbotron">
    <h3 style="color:black">Profile Page</h3>
    <h6 style="color:black">Nama Lengkap : Andre Aditya Pelealu</h6>
    <h6 style="color:black">Tempat, Tanggal Lahir : 14 April 1998</h6>
    <h6 style="color:black">Riwayat Pendidikan :  </h6>
    <h6 style="color:black">- SMA Negeri 6 Semarang 2013-2016</h6>
    <h6 style="color:black">- Universitas Dian Nuswantoro  Semarang 2016 - Sekarang</h6>
</div>

<br><br><br><br><br><br><br><br><br><br><br><br>
  		</center>
  		</div>

  	</div>
    </div>
    </div>

</body>
