

  <div class="post">
    <h3 class="title"><?php echo $post['judul']; ?></h3>
    <p><?php echo $post['post']; ?></p>
    <a href="<?php echo base_url('blog') ?>" class="btn btn-primary">Kembali ...</a>
  </div>
